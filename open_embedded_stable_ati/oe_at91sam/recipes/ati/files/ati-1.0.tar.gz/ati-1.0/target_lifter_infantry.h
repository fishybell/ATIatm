#ifndef __TARGET_LIFTER_INFANTRY_H__
#define __TARGET_LIFTER_INFANTRY_H__

// TODO - put #defines for pins here?

#endif // __TARGET_LIFTER_INFANTRY_H__
