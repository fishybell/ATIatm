/*
 * target.h
 */

#ifndef __TARGET_H__
#define __TARGET_H__


#define TARGET_DEVICES_MAX	32

#define TARGET_TYPE_NONE	0
#define TARGET_TYPE_LIFTER	1
#define TARGET_TYPE_MOVER	2

struct target_device
	{
	int 							type;
	char							*name;
	struct device           		*dev;
	const struct attribute_group* 	(*get_attr_group)(void);
	};

extern int 	target_sysfs_add	(struct target_device * target_device);
extern void target_sysfs_remove	(struct target_device * target_device);

#endif // __TARGET_H__
