//---------------------------------------------------------------------------
// target_infantry_lifter.c
//---------------------------------------------------------------------------
#include <linux/device.h>
#include <linux/interrupt.h>
#include <mach/gpio.h>

#include "target.h"
#include "target_lifter_infantry.h"
//---------------------------------------------------------------------------


#define LIFTER_TYPE  "infantry"

#define LIFTER_POSITION_DOWN   	0
#define LIFTER_POSITION_UP    	1
#define LIFTER_POSITION_MOVING  2
#define LIFTER_POSITION_ERROR   3

#define PIN_POSITION_ACTIVE   	0       		// Active low
#define PIN_POSITION_DOWN    	AT91_PIN_PA30   // BP3 on dev. board
#define PIN_POSITION_UP     	AT91_PIN_PA31   // BP4 on dev. board

#define PIN_MOTOR_ACTIVE    	0       		// Active low

#ifdef DEV_BOARD_REVB
	#define PIN_MOTOR_CONTROL    	AT91_PIN_PA6
#else
	#define PIN_MOTOR_CONTROL    	AT91_PIN_PB8
#endif

//---------------------------------------------------------------------------
// maps the position to position name
//---------------------------------------------------------------------------
static const char * lifter_position[] =
    {
    "down",
    "up",
    "moving",
    "error"
    };

//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
irqreturn_t down_position_int(int irq, void *dev_id, struct pt_regs *regs)
    {
    if (at91_get_gpio_value(PIN_POSITION_DOWN) == PIN_POSITION_ACTIVE)
        {
        printk(KERN_ALERT "down_position_int()\n");
        at91_set_gpio_value(PIN_MOTOR_CONTROL, !PIN_MOTOR_ACTIVE); // Turn motor off
        }

    return IRQ_HANDLED;
    }

//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
irqreturn_t up_position_int(int irq, void *dev_id, struct pt_regs *regs)
    {
    if (at91_get_gpio_value(PIN_POSITION_UP) == PIN_POSITION_ACTIVE)
        {
        printk(KERN_ALERT "up_position_int()\n");
        at91_set_gpio_value(PIN_MOTOR_CONTROL, !PIN_MOTOR_ACTIVE); // Turn motor off
        }

    return IRQ_HANDLED;
    }

//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
static int hardware_init(void)
    {
    int status = 0;

    // configure motor gpio for output and set initial output
    at91_set_gpio_output(PIN_MOTOR_CONTROL, !PIN_MOTOR_ACTIVE);

    // Configure position gpios for input and deglitch for interrupts
    at91_set_gpio_input(PIN_POSITION_DOWN, 1);
    at91_set_deglitch(PIN_POSITION_DOWN, 1);
    at91_set_gpio_input(PIN_POSITION_UP, 1);
    at91_set_deglitch(PIN_POSITION_UP, 1);

    status = request_irq(PIN_POSITION_DOWN, (void*)down_position_int, 0, "infantry_target_down", NULL);
    if (status != 0)
        {
        if (status == -EINVAL)
            {
            printk(KERN_ERR "request_irq(): Bad irq number or handler\n");
            }
        else if (status == -EBUSY)
            {
            printk(KERN_ERR "request_irq(): IRQ is busy, change your config\n");
            }
        return status;
        }

    status = request_irq(PIN_POSITION_UP, (void*)up_position_int, 0, "infantry_target_up", NULL);
    if (status != 0)
        {
        if (status == -EINVAL)
            {
            printk(KERN_ERR "request_irq(): Bad irq number or handler\n");
            }
        else if (status == -EBUSY)
            {
            printk(KERN_ERR "request_irq(): IRQ is busy, change your config\n");
            }

        return status;
        }

    return status;
    }

//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
static int hardware_exit(void)
    {
	free_irq(PIN_POSITION_DOWN, NULL);
	free_irq(PIN_POSITION_UP, NULL);
	return 0;
    }

//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
static int hardware_position_set(int position)
    {
	// with the infantry lifter we don't care about position,
	// just turn on the motor
	at91_set_gpio_value(PIN_MOTOR_CONTROL, PIN_MOTOR_ACTIVE); // Turn motor on
	return 0;
    }

//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
static int hardware_position_get(void)
    {
    if (at91_get_gpio_value(PIN_POSITION_DOWN) == PIN_POSITION_ACTIVE)
        {
        return LIFTER_POSITION_DOWN;
        }

    if (at91_get_gpio_value(PIN_POSITION_UP) == PIN_POSITION_ACTIVE)
        {
        return LIFTER_POSITION_UP;
        }

    // TODO - need to add some error reporting when it is in place
    return LIFTER_POSITION_MOVING;
    }

//---------------------------------------------------------------------------
// Handles reads to the type attribute through sysfs
//---------------------------------------------------------------------------
static ssize_t type_show(struct device *dev, struct device_attribute *attr, char *buf)
    {
    return sprintf(buf, "%s\n", LIFTER_TYPE);
    }

//---------------------------------------------------------------------------
// Handles reads to the position attribute through sysfs
//---------------------------------------------------------------------------
static ssize_t position_show(struct device *dev, struct device_attribute *attr, char *buf)
    {
    return sprintf(buf, "%s\n", lifter_position[hardware_position_get()]);
    }

//---------------------------------------------------------------------------
// Handles writes to the position attribute through sysfs
//---------------------------------------------------------------------------
static ssize_t position_store(struct device *dev, struct device_attribute *attr, const char *buf, size_t size)
    {
    ssize_t status = -EINVAL;

    if (sysfs_streq(buf, "up"))
        {
        printk(KERN_ALERT "[infantry lifter] user command up\n");
        status = 2;
        // need to check error condition first - TODO
        if (hardware_position_get() == LIFTER_POSITION_DOWN)
            {
            hardware_position_set(LIFTER_POSITION_UP);
            }
        }
    else if (sysfs_streq(buf, "down"))
        {
        printk(KERN_ALERT "[infantry lifter] user command down\n");
        status = 4;
        // need to check error condition first - TODO
        if (hardware_position_get() == LIFTER_POSITION_UP)
            {
            hardware_position_set(LIFTER_POSITION_DOWN);
            }
        }

    return status;
    }

//---------------------------------------------------------------------------
// maps attributes, r/w permissions, and handler functions
//---------------------------------------------------------------------------
static DEVICE_ATTR(type, 0444, type_show, NULL);
static DEVICE_ATTR(position, 0644, position_show, position_store);

//---------------------------------------------------------------------------
// Defines the attributes of the infantry target lifter for sysfs
//---------------------------------------------------------------------------
static const struct attribute * infantry_lifter_attrs[] =
    {
    &dev_attr_type.attr,
    &dev_attr_position.attr,
    NULL,
    };

//---------------------------------------------------------------------------
// Defines the attribute group of the infantry target lifter for sysfs
//---------------------------------------------------------------------------
const struct attribute_group infantry_lifter_attr_group =
    {
    .attrs = (struct attribute **) infantry_lifter_attrs,
    };

//---------------------------------------------------------------------------
// Returns the attribute group of the infantry target lifter
//---------------------------------------------------------------------------
const struct attribute_group * infantry_lifter_get_attr_group(void)
    {
    return &infantry_lifter_attr_group;
    }

//---------------------------------------------------------------------------
// declares the target_device that is added/removed through target.ko
//---------------------------------------------------------------------------
struct target_device target_device_lifter_infantry =
    {
    .type     		= TARGET_TYPE_LIFTER,
    .name     		= "infantry lifter",
    .dev     		= NULL,
    .get_attr_group	= infantry_lifter_get_attr_group,
    };

//---------------------------------------------------------------------------
// init handler for the module
//---------------------------------------------------------------------------
static int __init target_lifter_infantry_init(void)
    {
	hardware_init();
    return target_sysfs_add(&target_device_lifter_infantry);
    }

//---------------------------------------------------------------------------
// exit handler for the module
//---------------------------------------------------------------------------
static void __exit target_lifter_infantry_exit(void)
    {
	hardware_exit();
    target_sysfs_remove(&target_device_lifter_infantry);
    }


//---------------------------------------------------------------------------
// module declarations
//---------------------------------------------------------------------------
module_init(target_lifter_infantry_init);
module_exit(target_lifter_infantry_exit);
MODULE_LICENSE("proprietary");
MODULE_DESCRIPTION("ATI target lifter infantry module");
MODULE_AUTHOR("jpy");

